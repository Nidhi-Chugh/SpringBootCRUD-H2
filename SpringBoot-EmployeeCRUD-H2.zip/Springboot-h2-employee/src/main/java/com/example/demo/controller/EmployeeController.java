package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@RestController
public class EmployeeController
{
	@Autowired
	EmployeeRepository employeeRepository;
	
	@PostMapping("/createEmployee")
	public String createEmployee(@RequestBody Employee employee)
	{
		employeeRepository.save(employee);
		return " Employee record created successfully";
	}
	
	@GetMapping("/getAllEmployees")
	public List<Employee> getAllEmployees()
	{
		return employeeRepository.findAll();	
	}
	
	@GetMapping("/getEmployeeByDepartment/{dept}")
	@ResponseBody
	public List<Employee> getEmployeeByDepartment(@PathVariable String dept)
	{
		return employeeRepository.findByDept(dept);		
	}
	
	@PutMapping("/updateEmployee")
	public String updateEmployee(@RequestBody Employee employee)
	{
		employeeRepository.save(employee);
		return "Employee Details updated successfully";
	}
	
	@DeleteMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@RequestBody Employee employee)
	{
		employeeRepository.delete(employee);
		return "Employee details deleted successfully";
	}
}
