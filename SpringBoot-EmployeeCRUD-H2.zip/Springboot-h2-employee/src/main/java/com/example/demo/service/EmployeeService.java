//package com.example.demo.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.entity.Employee;
//import com.example.demo.repository.EmployeeRepository;
//
//@Service
//public class EmployeeService
//{
//	@Autowired
//	EmployeeRepository employeeRepository;
//	
//	
//	public Employee saveOrUpdateEmployee(Employee employee1)
//	
//	{	
//		 Optional<Employee> employee = employeeRepository.findById(employee1.getId());
//		         
//		        if(employee.isPresent()) 
//		        {
//		        	Employee newEntity = employee.get();
//		            newEntity.setName(employee1.getName());
//		            newEntity.setDept(employee1.getDept());
//		            newEntity.setSalary(employee1.getSalary());
//		 
//		            newEntity = employeeRepository.save(newEntity);
//		             
//		            return newEntity;
//		        } else {
//		            employee = employeeRepository.save(employee);
//		             
//		            return employee1;
//		        }
//		    } 
//	}
