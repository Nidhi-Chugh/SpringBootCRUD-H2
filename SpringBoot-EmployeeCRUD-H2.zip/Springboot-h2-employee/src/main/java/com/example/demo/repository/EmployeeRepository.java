package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository <Employee,Integer>
{

	List<Employee> findByDept(String dept);

	@Query(value = "Select * from employee where name=?",nativeQuery=true)
	public void saveOrUpdate(Employee employee, int id);

	Optional<Employee> save(Optional<Employee> employee);
	
	//void saveOrUpdate(Employee employee);


}
